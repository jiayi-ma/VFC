addpath('./data');
addpath('./SC');
addpath('./VFC');
% addpath('./L2E');
% addpath('./EM_TPS');
% addpath('../shape_matching/sc_demo/original');
% addpath('../VFC/images&homography');
% 
% oldcd = cd;
% cd ../vlfeat/toolbox
% vl_setup;
% cd(oldcd);