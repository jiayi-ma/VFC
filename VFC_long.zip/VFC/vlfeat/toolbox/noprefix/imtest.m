function varargout = imtest(varargin)
% VL_IMTEST
[varargout{1:nargout}] = vl_imtest(varargin{:});
