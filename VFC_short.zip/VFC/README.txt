* This is an example code for the algorithm described in

1. J. Zhao, J. Ma, J. Tian, J. Ma, and D. Zhang. "A robust method for vector field learning with application to mismatch removing", in CVPR 2011.

2. J. Ma, J. Zhao, J. Tian, X. Bai, and Z. Tu. "Regularized Vector Field Learning with Sparse Approximation for Mismatch Removal", Pattern Recognition 46(12), 3519--3532 (2013).

3. J. Ma, J. Zhao, J. Tian, A. L. Yuille, and Z. Tu. "Robust point matching via vector field consensus", IEEE Transactions on Image Processing 23(4), 1706--1721 (2014).
